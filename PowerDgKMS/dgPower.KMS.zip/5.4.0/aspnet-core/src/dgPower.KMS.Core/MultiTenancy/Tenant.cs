﻿using Abp.MultiTenancy;
using dgPower.KMS.Authorization.Users;

namespace dgPower.KMS.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
