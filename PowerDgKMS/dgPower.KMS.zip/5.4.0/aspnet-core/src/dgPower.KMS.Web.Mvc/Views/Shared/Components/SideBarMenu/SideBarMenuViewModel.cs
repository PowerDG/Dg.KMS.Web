﻿using Abp.Application.Navigation;

namespace dgPower.KMS.Web.Views.Shared.Components.SideBarMenu
{
    public class SideBarMenuViewModel
    {
        public UserMenu MainMenu { get; set; }
    }
}
