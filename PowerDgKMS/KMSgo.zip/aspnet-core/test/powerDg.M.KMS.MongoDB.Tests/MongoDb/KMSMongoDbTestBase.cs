﻿namespace powerDg.M.KMS.MongoDB
{
    public abstract class KMSMongoDbTestBase : KMSTestBase<KMSMongoDbTestModule> 
    {

    }
}
