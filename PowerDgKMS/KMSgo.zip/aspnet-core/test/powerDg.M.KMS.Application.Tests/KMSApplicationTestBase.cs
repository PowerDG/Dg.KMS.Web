﻿namespace powerDg.M.KMS
{
    public abstract class KMSApplicationTestBase : KMSTestBase<KMSApplicationTestModule> 
    {

    }
}
