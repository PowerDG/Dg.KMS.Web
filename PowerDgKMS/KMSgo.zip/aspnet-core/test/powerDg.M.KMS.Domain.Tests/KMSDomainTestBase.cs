﻿namespace powerDg.M.KMS
{
    public abstract class KMSDomainTestBase : KMSTestBase<KMSDomainTestModule> 
    {

    }
}
