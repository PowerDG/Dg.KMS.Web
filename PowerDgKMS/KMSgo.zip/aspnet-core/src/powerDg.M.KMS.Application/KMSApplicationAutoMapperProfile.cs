﻿using AutoMapper;

namespace powerDg.M.KMS
{
    public class KMSApplicationAutoMapperProfile : Profile
    {
        public KMSApplicationAutoMapperProfile()
        {
            /* You can configure your AutoMapper mapping configuration here.
             * Alternatively, you can split your mapping configurations
             * into multiple profile classes for a better organization. */
        }
    }
}
