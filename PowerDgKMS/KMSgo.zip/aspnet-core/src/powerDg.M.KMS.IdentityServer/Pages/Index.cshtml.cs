using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace powerDg.M.KMS.Pages
{
    public class IndexModel : AbpPageModel
    {
        public void OnGet()
        {
        }
    }
}