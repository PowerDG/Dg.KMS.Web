﻿using Volo.Abp.Localization;

namespace powerDg.M.KMS.Localization
{
    [LocalizationResourceName("KMS")]
    public class KMSResource
    {

    }
}