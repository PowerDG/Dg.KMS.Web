﻿namespace powerDg.M.KMS
{
    public static class KMSDomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
