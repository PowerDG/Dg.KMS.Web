﻿namespace powerDg.M.KMS.Settings
{
    public static class KMSSettings
    {
        private const string Prefix = "KMS";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}