﻿namespace DgKMS.Cube
{
    public class CubeConsts
    {
        public const string LocalizationSourceName = "Cube";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
