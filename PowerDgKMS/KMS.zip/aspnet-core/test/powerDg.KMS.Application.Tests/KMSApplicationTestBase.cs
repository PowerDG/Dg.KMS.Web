﻿namespace powerDg.KMS
{
    public abstract class KMSApplicationTestBase : KMSTestBase<KMSApplicationTestModule> 
    {

    }
}
