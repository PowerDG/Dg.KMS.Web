﻿namespace powerDg.KMS
{
    public abstract class KMSDomainTestBase : KMSTestBase<KMSDomainTestModule> 
    {

    }
}
