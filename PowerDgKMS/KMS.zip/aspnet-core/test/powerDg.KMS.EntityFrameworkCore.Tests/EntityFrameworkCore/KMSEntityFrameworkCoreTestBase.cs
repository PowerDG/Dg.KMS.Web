﻿using Volo.Abp;

namespace powerDg.KMS.EntityFrameworkCore
{
    public abstract class KMSEntityFrameworkCoreTestBase : KMSTestBase<KMSEntityFrameworkCoreTestModule> 
    {

    }
}
