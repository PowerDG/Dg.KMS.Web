﻿using Volo.Abp.Localization;

namespace powerDg.KMS.Localization
{
    [LocalizationResourceName("KMS")]
    public class KMSResource
    {

    }
}