﻿namespace powerDg.KMS
{
    public static class KMSDomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
