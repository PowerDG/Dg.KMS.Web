﻿namespace powerDg.KMS
{
    public static class KMSConsts
    {
        public const string DbTablePrefix = "App";

        public const string DbSchema = null;
    }
}
