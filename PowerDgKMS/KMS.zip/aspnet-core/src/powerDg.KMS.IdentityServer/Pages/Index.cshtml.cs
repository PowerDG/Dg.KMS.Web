using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;

namespace powerDg.KMS.Pages
{
    public class IndexModel : AbpPageModel
    {
        public void OnGet()
        {
        }
    }
}