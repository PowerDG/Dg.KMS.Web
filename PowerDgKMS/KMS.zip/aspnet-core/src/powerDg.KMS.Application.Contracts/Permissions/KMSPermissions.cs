﻿namespace powerDg.KMS.Permissions
{
    public static class KMSPermissions
    {
        public const string GroupName = "KMS";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}