﻿namespace dgPower.PKMS
{
    public class PKMSConsts
    {
        public const string LocalizationSourceName = "PKMS";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
