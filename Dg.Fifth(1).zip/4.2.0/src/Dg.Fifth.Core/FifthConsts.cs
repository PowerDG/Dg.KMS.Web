﻿namespace Dg.Fifth
{
    public class FifthConsts
    {
        public const string LocalizationSourceName = "Fifth";

        public const string ConnectionStringName = "Default";
    }
}