﻿namespace Dg.Fifth.Web.Startup
{
    public class PageNames
    {
        public const string Home = "Home";
        public const string About = "About";
    }
}
