namespace Dg.Fifth.Web.Controllers
{
    public class LayoutController : FifthControllerBase
    {

    }
}