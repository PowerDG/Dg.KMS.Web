﻿namespace Dg.KMS
{
    public class KMSConsts
    {
        public const string LocalizationSourceName = "KMS";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
