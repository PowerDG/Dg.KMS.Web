﻿using Abp.MultiTenancy;
using Dg.KMS.Authorization.Users;

namespace Dg.KMS.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
