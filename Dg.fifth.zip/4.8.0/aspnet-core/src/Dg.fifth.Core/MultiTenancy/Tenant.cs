﻿using Abp.MultiTenancy;
using Dg.fifth.Authorization.Users;

namespace Dg.fifth.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
