﻿namespace Dg.fifth
{
    public class fifthConsts
    {
        public const string LocalizationSourceName = "fifth";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
